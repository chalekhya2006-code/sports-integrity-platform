const express = require('express');
const axios = require('axios');
const { protect } = require('../middleware/auth');

const router = express.Router();

router.get('/', protect, async (req, res) => {
  const sport = (req.query.sport || 'Soccer').toLowerCase();
  const url = `https://www.thesportsdb.com/api/v1/json/3/livescore.php?s=${encodeURIComponent(sport)}`;
  try {
    const response = await axios.get(url, { timeout: 12000 });
    const events = (response.data && response.data.events) || [];
    res.json({ source: 'TheSportsDB', sport, events });
  } catch (error) {
    res.json({
      source: 'fallback',
      sport,
      events: [
        {
          strEvent: 'Demo FC vs Integrity United',
          strLeague: 'Integrity League',
          intHomeScore: '1',
          intAwayScore: '0',
          strStatus: '45:00'
        }
      ],
      note: 'Public API unavailable, showing demo data.'
    });
  }
});

module.exports = router;

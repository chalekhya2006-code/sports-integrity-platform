const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Media = require('../models/Media');
const Notification = require('../models/Notification');
const { protect } = require('../middleware/auth');
const { analyzeMedia } = require('../utils/mediaAnalysis');

const router = express.Router();
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, '-').toLowerCase()}`)
});

const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

router.post('/upload', protect, upload.single('media'), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No file uploaded' });
  const detection = analyzeMedia(req.file);
  const media = await Media.create({ originalName: req.file.originalname, fileName: req.file.filename, filePath: `/uploads/${req.file.filename}`, mimeType: req.file.mimetype, size: req.file.size, uploadedBy: req.user._id, detection });
  if (detection.label === 'potentially_fake' || detection.confidence >= 0.5) {
    await Notification.create({ title: 'Suspicious media detected', message: `${req.file.originalname} was flagged with confidence ${detection.confidence}.`, type: 'warning', source: 'media-analysis' });
  }
  res.status(201).json(media);
});

router.get('/', protect, async (req, res) => {
  const items = await Media.find().populate('uploadedBy', 'name email role').sort({ createdAt: -1 });
  res.json(items);
});

router.post('/:id/report', protect, async (req, res) => {
  const media = await Media.findByIdAndUpdate(req.params.id, { $inc: { reportCount: 1 } }, { new: true });
  if (!media) return res.status(404).json({ message: 'Media not found' });
  await Notification.create({ title: 'Media reported', message: `A user reported ${media.originalName}. Total reports: ${media.reportCount}.`, type: 'danger', source: 'user-report' });
  res.json(media);
});

router.get('/:id', protect, async (req, res) => {
  const media = await Media.findById(req.params.id).populate('uploadedBy', 'name email role');
  if (!media) return res.status(404).json({ message: 'Media not found' });
  res.json(media);
});

module.exports = router;

const express = require('express');
const { protect, requireAdmin } = require('../middleware/auth');
const User = require('../models/User');
const Media = require('../models/Media');
const Match = require('../models/Match');
const Notification = require('../models/Notification');

const router = express.Router();

router.get('/stats', protect, requireAdmin, async (req, res) => {
  const [users, mediaCount, matchCount, alertCount] = await Promise.all([
    User.countDocuments(),
    Media.countDocuments(),
    Match.countDocuments(),
    Notification.countDocuments({ type: { $in: ['warning', 'danger'] } })
  ]);
  res.json({ users, mediaCount, matchCount, alertCount });
});

module.exports = router;

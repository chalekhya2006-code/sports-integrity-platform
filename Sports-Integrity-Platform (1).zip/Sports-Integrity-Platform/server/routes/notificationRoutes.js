const express = require('express');
const Notification = require('../models/Notification');
const { protect, requireAdmin } = require('../middleware/auth');
const { summarizeSportsUpdate } = require('../utils/aiSummary');

const router = express.Router();

router.get('/', protect, async (req, res) => {
  const items = await Notification.find().sort({ createdAt: -1 }).limit(50);
  res.json(items);
});

router.post('/generate', protect, requireAdmin, async (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ message: 'text is required' });
  const summary = await summarizeSportsUpdate(text);
  const notification = await Notification.create({ title: 'AI Sports Update', message: summary, type: 'info', source: 'ai-summary' });
  res.status(201).json(notification);
});

router.post('/:id/seen', protect, async (req, res) => {
  const notification = await Notification.findByIdAndUpdate(req.params.id, { $addToSet: { seenBy: req.user._id } }, { new: true });
  if (!notification) return res.status(404).json({ message: 'Notification not found' });
  res.json(notification);
});

module.exports = router;

const express = require('express');
const Match = require('../models/Match');
const Event = require('../models/Event');
const { protect, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.get('/', protect, async (req, res) => {
  const { team, date, tournament, status } = req.query;
  const filter = {};
  if (team) filter.$or = [{ teamA: new RegExp(team, 'i') }, { teamB: new RegExp(team, 'i') }];
  if (tournament) filter.tournament = new RegExp(tournament, 'i');
  if (status) filter.status = status;
  if (date) {
    const day = new Date(date);
    const next = new Date(day);
    next.setDate(day.getDate() + 1);
    filter.date = { $gte: day, $lt: next };
  }
  const matches = await Match.find(filter).sort({ date: -1 });
  res.json(matches);
});

router.post('/', protect, requireAdmin, async (req, res) => {
  const match = await Match.create(req.body);
  res.status(201).json(match);
});

router.get('/upcoming', protect, async (req, res) => {
  const events = await Event.find({ date: { $gte: new Date() } }).sort({ date: 1 }).limit(10);
  res.json(events);
});

router.post('/events', protect, requireAdmin, async (req, res) => {
  const event = await Event.create(req.body);
  res.status(201).json(event);
});

module.exports = router;

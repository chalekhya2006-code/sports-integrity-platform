const mongoose = require('mongoose');

const matchSchema = new mongoose.Schema({
  sport: { type: String, default: 'Football' },
  tournament: { type: String, required: true },
  teamA: { type: String, required: true },
  teamB: { type: String, required: true },
  scoreA: { type: Number, default: 0 },
  scoreB: { type: Number, default: 0 },
  date: { type: Date, required: true },
  status: { type: String, enum: ['past', 'upcoming', 'live'], default: 'past' },
  notes: { type: String, default: '' }
}, { timestamps: true });

module.exports = mongoose.model('Match', matchSchema);

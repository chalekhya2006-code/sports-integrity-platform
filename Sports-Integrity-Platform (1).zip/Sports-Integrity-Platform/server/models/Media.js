const mongoose = require('mongoose');

const mediaSchema = new mongoose.Schema({
  originalName: String,
  fileName: String,
  filePath: String,
  mimeType: String,
  size: Number,
  uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  detection: {
    label: { type: String, default: 'unknown' },
    confidence: { type: Number, default: 0 },
    explanation: { type: String, default: '' }
  },
  reportCount: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Media', mediaSchema);

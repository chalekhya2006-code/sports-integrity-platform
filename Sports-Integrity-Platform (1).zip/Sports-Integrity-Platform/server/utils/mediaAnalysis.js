const path = require('path');

function analyzeMedia(file) {
  const ext = path.extname(file.originalname).toLowerCase();
  const isVideo = ['.mp4', '.mov', '.webm', '.mkv', '.avi'].includes(ext);
  const isImage = ['.jpg', '.jpeg', '.png', '.webp', '.gif'].includes(ext);
  let suspiciousScore = 0.15;
  const name = file.originalname.toLowerCase();
  if (name.includes('fake') || name.includes('deepfake') || name.includes('edited') || name.includes('ai')) suspiciousScore += 0.35;
  if (file.size < 100_000) suspiciousScore += 0.12;
  if (file.size > 25 * 1024 * 1024) suspiciousScore += 0.08;
  if (isVideo) suspiciousScore += 0.10;
  if (isImage) suspiciousScore += 0.05;
  if (name.includes('screenshot') || name.includes('screen')) suspiciousScore += 0.05;
  suspiciousScore = Math.max(0.02, Math.min(0.98, suspiciousScore));
  const realConfidence = 1 - suspiciousScore;
  const label = suspiciousScore >= 0.5 ? 'potentially_fake' : 'likely_real';
  const explanation = label === 'potentially_fake'
    ? 'The file name/metadata patterns and sizing signals can sometimes correlate with manipulated media.'
    : 'No strong manipulation signals were detected from the available metadata.';
  return { label, confidence: Number((label === 'potentially_fake' ? suspiciousScore : realConfidence).toFixed(2)), explanation, fileType: isImage ? 'image' : isVideo ? 'video' : 'unknown' };
}
module.exports = { analyzeMedia };

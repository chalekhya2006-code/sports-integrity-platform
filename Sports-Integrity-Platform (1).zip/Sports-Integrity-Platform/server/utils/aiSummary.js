const OpenAI = require('openai');

async function summarizeSportsUpdate(text) {
  if (!process.env.OPENAI_API_KEY) return `AI summary: ${text.slice(0, 180)}${text.length > 180 ? '...' : ''}`;
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
    input: `Summarize this sports integrity update in 2 concise sentences and mention suspicious or important patterns:

${text}`
  });
  const output = response.output_text || '';
  return output.trim() || `AI summary: ${text.slice(0, 180)}${text.length > 180 ? '...' : ''}`;
}
module.exports = { summarizeSportsUpdate };

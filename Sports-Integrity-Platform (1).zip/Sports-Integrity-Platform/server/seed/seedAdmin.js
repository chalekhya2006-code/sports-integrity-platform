require('dotenv').config();
const bcrypt = require('bcryptjs');
const connectDB = require('../config/db');
const User = require('../models/User');

async function seed() {
  await connectDB();
  const email = process.env.ADMIN_EMAIL || 'admin@sports.com';
  const password = process.env.ADMIN_PASSWORD || 'Admin123!';
  const existing = await User.findOne({ email });
  if (existing) {
    existing.role = 'admin';
    await existing.save();
    console.log('Admin already existed, role updated.');
  } else {
    const hash = await bcrypt.hash(password, 10);
    await User.create({ name: 'Admin', email, password: hash, role: 'admin' });
    console.log('Admin created.');
  }
  console.log(`Admin Email: ${email}`);
  console.log(`Admin Password: ${password}`);
  process.exit(0);
}
seed().catch((err) => { console.error(err); process.exit(1); });

require('dotenv').config();
const connectDB = require('../config/db');
const Match = require('../models/Match');
const Event = require('../models/Event');
const Notification = require('../models/Notification');

async function seed() {
  await connectDB();
  await Promise.all([
    Match.deleteMany({}),
    Event.deleteMany({}),
    Notification.deleteMany({})
  ]);

  await Match.insertMany([
    { sport: 'Football', tournament: 'Premier League', teamA: 'Arsenal', teamB: 'Chelsea', scoreA: 2, scoreB: 1, date: new Date('2026-03-20'), status: 'past', notes: 'Clean match record.' },
    { sport: 'Football', tournament: 'La Liga', teamA: 'Real Madrid', teamB: 'Barcelona', scoreA: 1, scoreB: 1, date: new Date('2026-03-18'), status: 'past', notes: 'Balanced performance.' },
    { sport: 'Cricket', tournament: 'IPL', teamA: 'MI', teamB: 'CSK', scoreA: 180, scoreB: 176, date: new Date('2026-03-15'), status: 'past', notes: 'High-scoring game.' }
  ]);

  await Event.insertMany([
    { title: 'UEFA Champions League Quarterfinal', sport: 'Football', tournament: 'UCL', venue: 'Paris', date: new Date('2026-04-02'), status: 'upcoming' },
    { title: 'India vs Australia ODI', sport: 'Cricket', tournament: 'International', venue: 'Mumbai', date: new Date('2026-04-05'), status: 'upcoming' }
  ]);

  await Notification.insertMany([
    { title: 'Match history synced', message: 'Past match data imported successfully.', type: 'info', source: 'seed' },
    { title: 'Integrity check ready', message: 'Upload a media file to run the detection pipeline.', type: 'warning', source: 'seed' }
  ]);

  console.log('Sample match/event/notification data inserted.');
  process.exit(0);
}

seed().catch((err) => { console.error(err); process.exit(1); });

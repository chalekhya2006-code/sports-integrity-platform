# Server

## Run
```bash
npm install
cp .env.example .env
npm run seed:admin
npm run dev
```

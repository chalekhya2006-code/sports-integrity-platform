# Sports Integrity Platform

A full-stack MERN application with:
- JWT auth
- Role-based access control
- Dashboard with live scores, past data, upcoming events
- Media upload and fake-detection scoring
- Notifications and admin controls

## Folder structure
- `server/` Express + MongoDB API
- `client/` React UI

## Setup

### 1) Server
```bash
cd server
npm install
cp .env.example .env
npm run seed:admin
npm run dev
```

### 2) Client
```bash
cd client
npm install
cp .env.example .env
npm run dev
```

## Test accounts
- Admin: `admin@sports.com`
- Password: `Admin123!`

## Postman
Import these endpoints:
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/live-scores?sport=Soccer`
- `GET /api/matches?status=past`
- `GET /api/matches/upcoming`
- `POST /api/media/upload` (form-data key: `media`)
- `GET /api/notifications`
- `POST /api/notifications/generate`
- `GET /api/admin/stats`

Add header:
`Authorization: Bearer <token>`

## Deployment
- Frontend: Vercel
- Backend: Render / Heroku
- Database: MongoDB Atlas

import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function PastData() {
  const [team, setTeam] = useState('')
  const [date, setDate] = useState('')
  const [tournament, setTournament] = useState('')
  const [matches, setMatches] = useState([])

  const load = async () => {
    const params = new URLSearchParams()
    if (team) params.set('team', team)
    if (date) params.set('date', date)
    if (tournament) params.set('tournament', tournament)
    params.set('status', 'past')
    const res = await api.get(`/matches?${params.toString()}`)
    setMatches(res.data)
  }

  useEffect(() => { load() }, [])

  return (
    <div className="panel">
      <h2>Past Match Data</h2>
      <div className="filters">
        <input placeholder="Filter by team" value={team} onChange={(e)=>setTeam(e.target.value)} />
        <input type="date" value={date} onChange={(e)=>setDate(e.target.value)} />
        <input placeholder="Tournament" value={tournament} onChange={(e)=>setTournament(e.target.value)} />
        <button className="btn primary" onClick={load}>Search</button>
      </div>

      <div className="list">
        {matches.map((m) => (
          <div className="list-item" key={m._id}>
            <strong>{m.teamA} vs {m.teamB}</strong>
            <span>{m.tournament} · {m.sport}</span>
            <small>{new Date(m.date).toLocaleDateString()} · Score {m.scoreA}-{m.scoreB}</small>
            <p>{m.notes}</p>
          </div>
        ))}
      </div>
    </div>
  )
}

import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function LiveScores() {
  const [sport, setSport] = useState('Soccer')
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)

  const load = async (value = sport) => {
    setLoading(true)
    const res = await api.get(`/live-scores?sport=${encodeURIComponent(value)}`)
    setData(res.data.events || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  return (
    <div className="panel">
      <div className="row-between">
        <div>
          <h2>Live Scores</h2>
          <p>Real-time score feed from a public sports API with fallback demo data.</p>
        </div>
        <div className="row">
          <input value={sport} onChange={(e)=>setSport(e.target.value)} placeholder="Sport" />
          <button className="btn primary" onClick={() => load()}>{loading ? 'Loading...' : 'Fetch'}</button>
        </div>
      </div>

      <div className="cards">
        {data.map((m, idx) => (
          <div className="card" key={idx}>
            <h3>{m.strEvent}</h3>
            <p>{m.strLeague}</p>
            <div className="score">{m.intHomeScore ?? '-'} : {m.intAwayScore ?? '-'}</div>
            <small>Status: {m.strStatus || 'Live'}</small>
          </div>
        ))}
      </div>
    </div>
  )
}

import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function UploadMedia() {
  const [file, setFile] = useState(null)
  const [items, setItems] = useState([])
  const [result, setResult] = useState(null)
  const [uploading, setUploading] = useState(false)

  const load = async () => {
    const res = await api.get('/media')
    setItems(res.data)
  }

  useEffect(() => { load() }, [])

  const upload = async (e) => {
    e.preventDefault()
    if (!file) return
    const form = new FormData()
    form.append('media', file)
    setUploading(true)
    try {
      const { data } = await api.post('/media/upload', form, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      setResult(data)
      setFile(null)
      await load()
    } finally {
      setUploading(false)
    }
  }

  const report = async (id) => {
    await api.post(`/media/${id}/report`)
    await load()
  }

  return (
    <div className="panel">
      <h2>Media Upload & Fake Detection</h2>
      <p>Upload an image or video. The server returns a confidence score and explanation.</p>

      <form className="upload-box" onSubmit={upload}>
        <input type="file" accept="image/*,video/*" onChange={(e)=>setFile(e.target.files[0])} />
        <button className="btn primary" disabled={uploading}>{uploading ? 'Uploading...' : 'Upload & Analyze'}</button>
      </form>

      {result && <div className="alert"><strong>Analysis:</strong> {result.detection?.label} | Confidence: {result.detection?.confidence}<p>{result.detection?.explanation}</p></div>}

      <h3>Uploaded Media</h3>
      <div className="cards">
        {items.map((m) => (
          <div className="card" key={m._id}>
            <h4>{m.originalName}</h4>
            <p>{m.mimeType}</p>
            <small>Detection: {m.detection?.label} ({m.detection?.confidence})</small>
            <small>Reports: {m.reportCount}</small>
            <div className="row">
              <a className="btn ghost" href={`${import.meta.env.VITE_API_URL || 'http://localhost:5000/api'}${m.filePath}`} target="_blank" rel="noreferrer">Open</a>
              <button className="btn" onClick={() => report(m._id)}>Report</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

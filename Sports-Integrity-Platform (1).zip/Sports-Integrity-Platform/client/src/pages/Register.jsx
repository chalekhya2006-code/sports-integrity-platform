import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function Register() {
  const { register } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const submit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    try {
      await register(form.name, form.email, form.password)
      navigate('/dashboard')
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="auth-wrap">
      <form className="auth-card" onSubmit={submit}>
        <h2>Create account</h2>
        <p>Join the integrity platform</p>
        {error && <div className="alert error">{error}</div>}
        <input placeholder="Full name" value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})} />
        <input placeholder="Email" type="email" value={form.email} onChange={(e)=>setForm({...form,email:e.target.value})} />
        <input placeholder="Password (min 6 chars)" type="password" value={form.password} onChange={(e)=>setForm({...form,password:e.target.value})} />
        <button className="btn primary" disabled={loading}>{loading ? 'Creating...' : 'Register'}</button>
        <span className="muted">Already have an account? <Link to="/login">Login</Link></span>
      </form>
    </div>
  )
}

import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function AdminPanel() {
  const [stats, setStats] = useState(null)
  const [users, setUsers] = useState([])

  const load = async () => {
    const [statsRes, usersRes] = await Promise.all([api.get('/admin/stats'), api.get('/users')])
    setStats(statsRes.data)
    setUsers(usersRes.data)
  }

  useEffect(() => { load() }, [])

  const changeRole = async (id, role) => {
    await api.patch(`/users/${id}/role`, { role })
    await load()
  }

  return (
    <div className="panel">
      <h2>Admin Dashboard</h2>
      {stats && (
        <div className="stats-row">
          <div className="stat"><strong>{stats.users}</strong><span>Total users</span></div>
          <div className="stat"><strong>{stats.mediaCount}</strong><span>Media files</span></div>
          <div className="stat"><strong>{stats.matchCount}</strong><span>Matches</span></div>
          <div className="stat"><strong>{stats.alertCount}</strong><span>Alerts</span></div>
        </div>
      )}
      <h3>User management</h3>
      <div className="list">
        {users.map((u) => (
          <div className="list-item" key={u._id}>
            <strong>{u.name}</strong>
            <span>{u.email}</span>
            <small>{u.role}</small>
            <div className="row">
              <button className="btn ghost" onClick={() => changeRole(u._id, 'user')}>User</button>
              <button className="btn" onClick={() => changeRole(u._id, 'admin')}>Admin</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

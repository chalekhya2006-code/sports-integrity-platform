import React from 'react'
import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="auth-wrap">
      <div className="auth-card">
        <h2>Page not found</h2>
        <p>The page you opened does not exist.</p>
        <Link className="btn primary" to="/dashboard">Go Home</Link>
      </div>
    </div>
  )
}

import React, { useEffect, useState } from 'react'
import api from '../api/client'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

export default function Dashboard() {
  const [stats, setStats] = useState({ live: [], matches: [], events: [], notifications: [] })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      try {
        const [liveRes, matchesRes, eventsRes, notifRes] = await Promise.all([
          api.get('/live-scores?sport=Soccer'),
          api.get('/matches?status=past'),
          api.get('/matches/upcoming'),
          api.get('/notifications')
        ])
        setStats({ live: liveRes.data.events || [], matches: matchesRes.data || [], events: eventsRes.data || [], notifications: notifRes.data || [] })
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const chartData = stats.matches.slice(0, 6).map((m) => ({
    name: `${m.teamA.slice(0, 4)} vs ${m.teamB.slice(0, 4)}`,
    scoreA: m.scoreA,
    scoreB: m.scoreB
  }))

  if (loading) return <div className="panel">Loading dashboard...</div>

  return (
    <div className="dashboard-grid">
      <section className="panel hero">
        <h2>Welcome to the Sports Integrity Platform</h2>
        <p>Monitor live scores, review match history, upload media, and flag suspicious content.</p>
        <div className="stats-row">
          <div className="stat"><strong>{stats.live.length}</strong><span>Live matches</span></div>
          <div className="stat"><strong>{stats.matches.length}</strong><span>Past matches</span></div>
          <div className="stat"><strong>{stats.events.length}</strong><span>Upcoming events</span></div>
          <div className="stat"><strong>{stats.notifications.length}</strong><span>Alerts</span></div>
        </div>
      </section>

      <section className="panel">
        <h3>Match analytics</h3>
        <div style={{ width: '100%', height: 260 }}>
          <ResponsiveContainer>
            <BarChart data={chartData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="scoreA" />
              <Bar dataKey="scoreB" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="panel">
        <h3>Live scores</h3>
        <div className="list">
          {stats.live.map((item, idx) => (
            <div key={idx} className="list-item">
              <strong>{item.strEvent}</strong>
              <span>{item.strLeague} · {item.strStatus || 'Live'}</span>
              <small>{item.intHomeScore ?? '-'} : {item.intAwayScore ?? '-'}</small>
            </div>
          ))}
          {!stats.live.length && <p className="muted">No live matches available.</p>}
        </div>
      </section>

      <section className="panel">
        <h3>Upcoming events</h3>
        <div className="list">
          {stats.events.map((event) => (
            <div key={event._id} className="list-item">
              <strong>{event.title}</strong>
              <span>{event.tournament}</span>
              <small>{new Date(event.date).toLocaleString()}</small>
            </div>
          ))}
        </div>
      </section>

      <section className="panel full">
        <h3>Latest notifications</h3>
        <div className="list">
          {stats.notifications.map((n) => (
            <div key={n._id} className={`list-item ${n.type}`}>
              <strong>{n.title}</strong>
              <span>{n.message}</span>
              <small>{new Date(n.createdAt).toLocaleString()}</small>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}

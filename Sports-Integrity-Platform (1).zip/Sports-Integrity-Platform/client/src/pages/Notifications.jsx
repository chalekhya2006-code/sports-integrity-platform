import React, { useEffect, useState } from 'react'
import api from '../api/client'

export default function Notifications() {
  const [items, setItems] = useState([])
  const [text, setText] = useState('')
  const [message, setMessage] = useState('')

  const load = async () => {
    const res = await api.get('/notifications')
    setItems(res.data)
  }

  useEffect(() => { load() }, [])

  const generate = async () => {
    const res = await api.post('/notifications/generate', { text })
    setMessage(`Created: ${res.data.title}`)
    setText('')
    await load()
  }

  return (
    <div className="panel">
      <h2>Notifications Panel</h2>
      <div className="upload-box">
        <textarea rows="4" placeholder="Paste sports update text for AI summarization" value={text} onChange={(e)=>setText(e.target.value)} />
        <button className="btn primary" onClick={generate}>Generate AI Notification</button>
      </div>
      {message && <div className="alert success">{message}</div>}
      <div className="list">
        {items.map((n) => (
          <div className={`list-item ${n.type}`} key={n._id}>
            <strong>{n.title}</strong>
            <span>{n.message}</span>
            <small>{n.source} · {new Date(n.createdAt).toLocaleString()}</small>
          </div>
        ))}
      </div>
    </div>
  )
}

import React, { useEffect, useState } from 'react'
import { Outlet } from 'react-router-dom'
import Sidebar from './Sidebar'
import Header from './Header'

export default function Layout() {
  const [theme, setTheme] = useState(document.documentElement.dataset.theme || 'dark')
  useEffect(() => {
    document.documentElement.dataset.theme = theme
    localStorage.setItem('sip-theme', theme)
  }, [theme])
  return (
    <div className="app-shell">
      <Sidebar />
      <main className="main">
        <Header onToggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')} />
        <Outlet />
      </main>
    </div>
  )
}

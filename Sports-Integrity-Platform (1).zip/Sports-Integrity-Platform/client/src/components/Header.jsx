import React from 'react'
import { useAuth } from '../context/AuthContext'

export default function Header({ onToggleTheme }) {
  const { user, logout } = useAuth()
  return (
    <header className="header">
      <div>
        <h1>Sports Integrity Platform</h1>
        <p>Protecting sports digital media from manipulation and misinformation.</p>
      </div>
      <div className="header-actions">
        <button className="btn ghost" onClick={onToggleTheme}>Toggle theme</button>
        <div className="user-chip">
          <span>{user?.name}</span>
          <small>{user?.role}</small>
        </div>
        <button className="btn" onClick={logout}>Logout</button>
      </div>
    </header>
  )
}

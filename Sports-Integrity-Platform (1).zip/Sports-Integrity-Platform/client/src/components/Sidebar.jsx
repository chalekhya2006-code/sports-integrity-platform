import React from 'react'
import { NavLink } from 'react-router-dom'

const items = [
  ['Dashboard', '/dashboard'],
  ['Live Scores', '/live-scores'],
  ['Past Data', '/past-data'],
  ['Upload', '/upload'],
  ['Notifications', '/notifications'],
  ['Admin Panel', '/admin']
]

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-badge">SIP</div>
        <div>
          <h2>Sports Integrity</h2>
          <p>Authenticity dashboard</p>
        </div>
      </div>
      <nav className="nav">
        {items.map(([label, to]) => (
          <NavLink key={to} to={to} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            {label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}

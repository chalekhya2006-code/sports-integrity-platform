# Client

## Run
```bash
npm install
cp .env.example .env
npm run dev
```
